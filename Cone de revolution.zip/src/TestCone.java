
public class TestCone {
    public static void main (String[] args){
        System.out.println(Cone.getNbCone());

        Cone cone1 = new Cone(3,5);
        Cone cone2 = new Cone();

        System.out.println(Cone.getNbCone());
    }
}
