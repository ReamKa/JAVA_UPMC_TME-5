public class Cone {
    public final double PI = 3.14159;
    private double r;
    private double h;
    public static int cpt = 0;
    public int nbCones;

    public Cone(double r, double h){
        this.r = r;
        this.h = h ;
        nbCones = cpt++;
    }
    public Cone(){
        this(0 + (Math.random() * 10),0 + (Math.random() * 10));
    }
    public double getVolume(){
        return (1/3 * PI*(r*r)*h);
    }
    public String toString(){
        return "Cone r = " + r + " h = "+h+ " V = "+getVolume();
    }
    public static int getNbCone(){
        return cpt;
    }

}
